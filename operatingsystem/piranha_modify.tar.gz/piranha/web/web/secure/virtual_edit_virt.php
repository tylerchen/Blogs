<?php
        $selected_host = $_GET['selected_host'];
	$vev_action = "";

	if (isset($_GET['vev_action'])) {
		$vev_action = $_GET['vev_action'];
	}

	if ($vev_action == "CANCEL") {
		/* Redirect browser to editing page */
		header("Location: virtual_main.php?selected_host=$selected_host");
		/* Make sure that code below does not get executed when we redirect. */
		exit;
	}

	if (($selected_host == "")) {
		header("Location: virtual_main.php");
		exit;
	}

	if ($vev_action == "EDIT") {
		/* Redirect browser to editing page */
		header("Location: virtual_edit_services.php?selected_host=$selected_host");
		/* Make sure that code below does not get executed when we redirect. */
		exit;
	}
	
	/* try and make this page non cacheable */
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");             // Date in the past
	header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");// always modified
	header("Cache-Control: no-cache, must-revalidate");           // HTTP/1.1
	header("Pragma: no-cache");                                   // HTTP/1.0

	require('parse.php'); /* read in the config! Hurragh! */

        $temp = explode(" ", $virt[$selected_host]['address']);

	if ( $vev_action == "ACCEPT" ) {

		/* we don't allow for deletions from here */
                $hostname = $_GET['hostname'];
		if ($hostname == "")	{
			$hostname = $virt[$selected_host]['virtual'];
		} else {
			/* lets just squeeze out those spaces that would choke the parser */
			$virt[$selected_host]['virtual'] = str_replace (" ", "_", $hostname);
		}

                $virt[$selected_host]['port']			=	$_GET['port'];
                // $virt[$selected_host]['address']		=	$temp[0];
                $virt[$selected_host]['protocol']		=	$_GET['protocol'];
                $virt[$selected_host]['reentry']		=	$_GET['reentry'];
                $virt[$selected_host]['timeout']		=	$_GET['timeout'];
                $virt[$selected_host]['quiesce_server']		=	$_GET['quiesce_server'];
                $virt[$selected_host]['load_monitor']		=	$_GET['load'];
                $sched = $_GET['sched'];
                switch ($sched) {
                        case "Round robin"					:	$sched="rr"; break;
                        case "Weighted least-connections"			:	$sched="wlc"; break;
                        case "Weighted round robin"				:	$sched="wrr"; break;
                        case "Least-connection"					:	$sched="lc"; break;
                        case "Locality-Based Least-Connection Scheduling"	:	$sched="lblc"; break;
                        case "Locality-Based Least-Connection Scheduling (R)"	:	$sched="lblcr"; break;
                        case "Destination Hash Scheduling"			:	$sched="dh"; break;
                        case "Source Hash Scheduling"				:	$sched="sh"; break;
                        default							:	$sched="wlc"; break;
                }
                $virt[$selected_host]['scheduler']		=	$sched;
                $virt[$selected_host]['persistent']		=	$_GET['persistent'];
                $pmask = $_GET['pmask'];
                if ($pmask != "Unused" ) {
                        $virt[$selected_host]['pmask']		=	$pmask;
                } else {
                        $virt[$selected_host]['pmask']		=	"";
                }
                $vip_nmask = $_GET['vip_nmask'];
                if ($vip_nmask != "Unused" ) {
                        $virt[$selected_host]['vip_nmask']	=	$vip_nmask;
                } else {
                        $virt[$selected_host]['vip_nmask']	=	"";
                }

                $virt[$selected_host]['fwmark']		=	$_GET['fwmark'];

                $temp[0] = $_GET['address'];
                $temp[1] = $_GET['device'];
                $virt[$selected_host]['sorry_server']       =       $_GET['sorry_server'];
                $virt[$selected_host]['address']      		=       $_GET['address'] . " " . $_GET['device'];
	}

?>
<HTML>
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML Strict Level 3//EN">

<HEAD>

<TITLE>Piranha (Virtual Servers - Editing virtual server)</TITLE>

<STYLE TYPE="text/css">
<!-- 

TD      {
        font-family: helvetica, sans-serif;
        }
        
.logo   {
        color: #FFFFFF;
        }
        
A.logolink      {
        color: #FFFFFF;
        font-size: .8em;
        }
        
.taboff {
        color: #FFFFFF;
        }
        
.tabon  {
        color: #999999;
        }
        
.title  {
        font-size: .8em;
        font-weight: bold;
        color: #660000;
        }
        
.smtext {
        font-size: .8em;
        }
        
.green  {
        color: 
	}
// -->
</STYLE>

</HEAD>

<BODY BGCOLOR="#660000">

<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="5">
	<TR BGCOLOR="#CC0000"> <TD CLASS="logo"> <B>PIRANHA</B> CONFIGURATION TOOL </TD>
	<TD ALIGN=right CLASS="logo">
            <A HREF="introduction.html" CLASS="logolink">
            INTRODUCTION</A> | <A HREF="help.php" CLASS="logolink">
            HELP</A></TD>
	</TR>
</TABLE>

<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="5">
        <TR>
            <TD>&nbsp;<BR><FONT SIZE="+2" COLOR="#CC0000">EDIT VIRTUAL SERVER</FONT><BR>&nbsp;</TD>
        </TR>
</TABLE>

<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="0"><TR><TD BGCOLOR="#FFFFFF">


<TABLE WIDTH="100%" BORDER="0" CELLSPACING="1" CELLPADDING="5">
        <TR BGCOLOR="#666666">
                <TD WIDTH="25%" ALIGN="CENTER"> <A HREF="control.php" NAME="Control/Monitoring" CLASS="taboff"><B>CONTROL/MONITORING</B></A> </TD>
                <TD WIDTH="25%" ALIGN="CENTER"> <A HREF="global_settings.php" NAME="Global Settings" CLASS="taboff"><B>GLOBAL SETTINGS</B></A> </TD>
                <TD WIDTH="25%" ALIGN="CENTER"> <A HREF="redundancy.php" NAME="Redundancy" CLASS="taboff"><B>REDUNDANCY</B></A> </TD>
                <TD WIDTH="25%" ALIGN="CENTER" BGCOLOR="#ffffff"> <A HREF="virtual_main.php" NAME="Virtual" CLASS="tabon"><B>VIRTUAL SERVERS</B></A> </TD>
        </TR>
</TABLE>
<?php
	// echo "Query = $QUERY_STRING";

?>

<?php if ($prim['service'] == "fos") { ?>
<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="5">
        <TR BGCOLOR="#EEEEEE">
                <TD WIDTH="60%">EDIT:
		
		<A HREF="virtual_edit_virt.php<?php if (!empty($selected_host)) { echo "?selected_host=$selected_host"; } ?> " CLASS="tabon" NAME="FAILOVER">FAILOVER</A>
		&nbsp;|&nbsp;

                <A HREF="virtual_edit_services.php<?php if (!empty($selected_host)) { echo "?selected_host=$selected_host"; } ?> " NAME="MONITORING SCRIPTS">MONITORING SCRIPTS</A></TD>

        </TR>
</TABLE>

<?php } else { ?>
<TABLE WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="5">
        <TR BGCOLOR="#EEEEEE">
                <TD WIDTH="60%">EDIT:
		
		<A HREF="virtual_edit_virt.php<?php if (!empty($selected_host)) { echo "?selected_host=$selected_host"; } ?> " CLASS="tabon" NAME="VIRTUAL SERVER">VIRTUAL SERVER</A>
		&nbsp;|&nbsp;

                <A HREF="virtual_edit_real.php<?php if (!empty($selected_host)) { echo "?selected_host=$selected_host"; } ?> " NAME="REAL SERVER">REAL SERVER</A>
		&nbsp;|&nbsp;

                <A HREF="virtual_edit_services.php<?php if (!empty($selected_host)) { echo "?selected_host=$selected_host"; } ?> " NAME="MONITORING SCRIPTS">MONITORING SCRIPTS</A></TD>

        </TR>
</TABLE>
<?php } ?>

<FORM METHOD="GET" ENCTYPE="application/x-www-form-urlencoded" ACTION="virtual_edit_virt.php">
<TABLE>
	<TR>
		<TD>Name:</TD>
		<TD><INPUT TYPE="TEXT" NAME="hostname" VALUE= <?php echo $virt[$selected_host]['virtual'] ; ?>></TD>
	</TR>
	<TR>

		<TD>Application port:</TD>
		<TD><INPUT TYPE="TEXT" NAME="port" VALUE=<?php echo  $virt[$selected_host]['port'] ?>></TD>
	</TR>
	<TR>
		<TD>Protocol:</TD>
		<TD>
			<SELECT NAME="protocol">
				<OPTION <?php if (($virt[$selected_host]['protocol'] == "tcp") || 
					       ($virt[$selected_host]['protocol'] == "")) { echo "SELECTED"; } ?>> tcp
				<OPTION <?php if ($virt[$selected_host]['protocol'] == "udp") { echo "SELECTED"; } ?>> udp
			</SELECT>
		</TD>

	</TR>

	<TR>
		<TD>Virtual IP Address: </TD>
		<TD><INPUT TYPE="TEXT" NAME="address" VALUE=<?php echo $temp[0] ?>></TD>
	</TR>
	<TR>
		<TD> Virtual IP Network Mask:</TD>
		<TD>
			<SELECT NAME="vip_nmask">
				<?php if (!isset($virt[$selected_host]['vip_nmask'])) { 
					$virt[$selected_host]['vip_nmask'] = "0.0.0.0";
				} ?>

				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "0.0.0.0") { echo "SELECTED"; } ?>> Unused
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.255.255") { echo "SELECTED"; } ?>> 255.255.255.255
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.255.252") { echo "SELECTED"; } ?>> 255.255.255.252
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.255.248") { echo "SELECTED"; } ?>> 255.255.255.248
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.255.240") { echo "SELECTED"; } ?>> 255.255.255.240
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.255.224") { echo "SELECTED"; } ?>> 255.255.255.224
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.255.192") { echo "SELECTED"; } ?>> 255.255.255.192
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.255.128") { echo "SELECTED"; } ?>> 255.255.255.128
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.255.0")   { echo "SELECTED"; } ?>> 255.255.255.0

				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.252.0")   { echo "SELECTED"; } ?>> 255.255.252.0
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.248.0")   { echo "SELECTED"; } ?>> 255.255.248.0
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.240.0")   { echo "SELECTED"; } ?>> 255.255.240.0
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.224.0")	{ echo "SELECTED"; } ?>> 255.255.224.0
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.192.0")	{ echo "SELECTED"; } ?>> 255.255.192.0
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.128.0")	{ echo "SELECTED"; } ?>> 255.255.128.0
				<OPTION <?php if ($virt[$selected_host]['vip_nmask'] == "255.255.0.0")	{ echo "SELECTED"; } ?>> 255.255.0.0

			</SELECT>
		</TD>
	</TR>
	<TR>
		<TD>Sorry Server: </TD>
		<TD><INPUT TYPE="TEXT" NAME="sorry_server" VALUE=<?php echo $virt[$selected_host]['sorry_server'] ?>></TD>
	</TR>
	<TR>
		<TD>Firewall Mark: </TD>
		<TD> <INPUT TYPE="TEXT" NAME="fwmark" VALUE="<?php if (isset($virt[$selected_host]['fwmark'])) {
								      echo $virt[$selected_host]['fwmark']; } ?>"></TD>
	</TR>

	<TR>
		<TD>Device: </TD>
		<TD> <INPUT TYPE="TEXT" NAME="device" VALUE="<?php echo $temp[1]; ?>"></TD>
	</TR>
	<TR>
		<TD>Re-entry Time: </TD>
		<TD> <INPUT TYPE="TEXT" NAME="reentry" VALUE=<?php echo $virt[$selected_host]['reentry'] ?>></TD>
	</TR>
	<TR>
		<TD>Service timeout: </TD>
		<TD> <INPUT TYPE="TEXT" NAME="timeout" VALUE=<?php echo $virt[$selected_host]['timeout'] ?>></TD>
	</TR>
	<TR>
		<TD>Quiesce server:</TD>
		<TD>

		<input type="radio" name="quiesce_server" value="1" <?php if ($virt[$selected_host]['quiesce_server'] == "1")		{ echo "CHECKED"; } ?> > Yes
		<input type="radio" name="quiesce_server" value="0" <?php if (($virt[$selected_host]['quiesce_server'] == "0" ) || ( $virt[$selected_host]['quiesce_server'] == "" ) )	{ echo "CHECKED"; } ?> > No

		</TD>
	</TD>	
	<TR>
		<TD> Load monitoring tool:</TD>
		<TD>
		<SELECT NAME="load">
			<OPTION <?php if ($virt[$selected_host]['load_monitor'] == "none")		{ echo "SELECTED"; } ?> > none
			<OPTION <?php if ($virt[$selected_host]['load_monitor'] == "rup")		{ echo "SELECTED"; } ?> > rup
			<OPTION <?php if ($virt[$selected_host]['load_monitor'] == "ruptime")	{ echo "SELECTED"; } ?> > ruptime
		</SELECT>
		</TD>
	</TR>
	<TR>
		<TD> Scheduling: </TD>
		<TD>
		<SELECT NAME="sched">
			<OPTION <?php if ($virt[$selected_host]['scheduler'] == "rr")	{ echo "SELECTED"; } ?>> Round robin
			<OPTION <?php if ($virt[$selected_host]['scheduler'] == "wlc")	{ echo "SELECTED"; } ?>> Weighted least-connections
			<OPTION <?php if ($virt[$selected_host]['scheduler'] == "wrr")	{ echo "SELECTED"; } ?>> Weighted round robin
			<OPTION <?php if ($virt[$selected_host]['scheduler'] == "lc")	{ echo "SELECTED"; } ?>> Least-connection
			<OPTION <?php if ($virt[$selected_host]['scheduler'] == "lblc")	{ echo "SELECTED"; } ?>> Locality-Based Least-Connection Scheduling
			<OPTION <?php if ($virt[$selected_host]['scheduler'] == "lblcr")	{ echo "SELECTED"; } ?>> Locality-Based Least-Connection Scheduling (R)
			<OPTION <?php if ($virt[$selected_host]['scheduler'] == "dh")	{ echo "SELECTED"; } ?>> Destination Hash Scheduling
			<OPTION <?php if ($virt[$selected_host]['scheduler'] == "sh")	{ echo "SELECTED"; } ?>> Source Hash Scheduling
		</SELECT>
		</TD>
	</TR>

	<TR>
		<TD> Persistence:</TD>
		<TD><INPUT TYPE="TEXT" NAME="persistent" VALUE=<?php echo $virt[$selected_host]['persistent'] ?>></TD>
	</TR>
	<TR>
		<TD> Persistence Network Mask:</TD>
		<TD>
		<SELECT NAME="pmask">
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "") { echo "SELECTED"; } ?>> Unused
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.255.255")	{ echo "SELECTED"; } ?>> 255.255.255.255
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.255.252")	{ echo "SELECTED"; } ?>> 255.255.255.252
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.255.248")	{ echo "SELECTED"; } ?>> 255.255.255.248
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.255.240")	{ echo "SELECTED"; } ?>> 255.255.255.240
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.255.224")	{ echo "SELECTED"; } ?>> 255.255.255.224
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.255.192")	{ echo "SELECTED"; } ?>> 255.255.255.192
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.255.128") 	{ echo "SELECTED"; } ?>> 255.255.255.128
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.255.0")   	{ echo "SELECTED"; } ?>> 255.255.255.0

			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.252.0")   	{ echo "SELECTED"; } ?>> 255.255.252.0
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.248.0")   	{ echo "SELECTED"; } ?>> 255.255.248.0
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.240.0")   	{ echo "SELECTED"; } ?>> 255.255.240.0
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.224.0")	{ echo "SELECTED"; } ?>> 255.255.224.0
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.192.0")	{ echo "SELECTED"; } ?>> 255.255.192.0
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.128.0")	{ echo "SELECTED"; } ?>> 255.255.128.0
			<OPTION <?php if ($virt[$selected_host]['pmask'] == "255.255.0.0")		{ echo "SELECTED"; } ?>> 255.255.0.0

		</SELECT>
		</TD>
	</TR>
</TABLE>
<?php echo "<INPUT TYPE=HIDDEN NAME=selected_host VALUE=$selected_host>" ?>

<TABLE WIDTH="100%" BORDER="0" CELLSPACING="1" CELLPADDING="5">
        <TR BGCOLOR="#666666">
                <TD>
                        <INPUT TYPE="Submit" NAME="vev_action" VALUE="ACCEPT">  
                        <SPAN CLASS="taboff">-- Click here to apply changes to this page</SPAN>
                </TD>
        </TR>
</TABLE>

<?php open_file ("w+"); write_config(""); ?>
</FORM>
</TD></TR></TABLE>
</BODY>
</HTML>
